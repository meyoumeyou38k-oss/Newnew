package com.lerza.player.ui

import android.animation.ObjectAnimator
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.LinearInterpolator
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.lerza.player.R
import com.lerza.player.databinding.ActivityFullscreenPlayerBinding
import com.lerza.player.model.MediaTrack
import com.lerza.player.player.PlaybackService
import java.util.Locale

class FullScreenPlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFullscreenPlayerBinding
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var currentTrack: MediaTrack? = null
    private var discAnimator: ObjectAnimator? = null

    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            progressHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFullscreenPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("track", MediaTrack::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("track") as? MediaTrack
        }

        setupUI()
        initMediaController()
    }

    private fun setupUI() {
        binding.btnBack.setOnClickListener { finish() }

        currentTrack?.let { track ->
            binding.trackTitle.text = track.title
            binding.trackArtist.text = track.artist
            binding.totalTimeText.text = formatDuration(track.duration)
            binding.playerSeekBar.max = track.duration.toInt()
        }

        setupDiscAnimation()

        binding.playerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    binding.currentTimeText.text = formatDuration(progress.toLong())
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                seekBar?.let {
                    controller?.seekTo(it.progress.toLong())
                }
            }
        })

        binding.btnPlayPause.setOnClickListener {
            controller?.let { player ->
                if (player.isPlaying) {
                    player.pause()
                } else {
                    player.play()
                }
                updatePlayPauseState()
            }
        }

        binding.btnNext.setOnClickListener {
            controller?.seekToNextMediaItem()
        }

        binding.btnPrevious.setOnClickListener {
            controller?.seekToPreviousMediaItem()
        }

        binding.btnRepeat.setOnClickListener {
            controller?.let { player ->
                val nextMode = when (player.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                player.repeatMode = nextMode
                val color = if (nextMode != Player.REPEAT_MODE_OFF) R.color.accent_cyan else R.color.text_secondary
                binding.btnRepeat.setColorFilter(getColor(color))
            }
        }

        binding.btnShuffle.setOnClickListener {
            controller?.let { player ->
                player.shuffleModeEnabled = !player.shuffleModeEnabled
                val color = if (player.shuffleModeEnabled) R.color.accent_cyan else R.color.text_secondary
                binding.btnShuffle.setColorFilter(getColor(color))
            }
        }
    }

    private fun setupDiscAnimation() {
        discAnimator = ObjectAnimator.ofFloat(binding.albumCard, "rotation", 0f, 360f).apply {
            duration = 16000
            repeatCount = ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
        }
    }

    private fun initMediaController() {
        val sessionToken = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updatePlayPauseState()
                }
            })
            updatePlayPauseState()
            progressHandler.post(progressRunnable)
        }, MoreExecutors.directExecutor())
    }

    private fun updatePlayPauseState() {
        val isPlaying = controller?.isPlaying == true
        binding.btnPlayPause.setImageResource(
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )
        if (isPlaying) {
            if (discAnimator?.isStarted == true) {
                discAnimator?.resume()
            } else {
                discAnimator?.start()
            }
        } else {
            discAnimator?.pause()
        }
    }

    private fun updateProgress() {
        controller?.let { player ->
            val position = player.currentPosition
            val duration = if (player.duration > 0) player.duration else (currentTrack?.duration ?: 0)
            binding.playerSeekBar.max = duration.toInt()
            binding.playerSeekBar.progress = position.toInt()
            binding.currentTimeText.text = formatDuration(position)
            binding.totalTimeText.text = formatDuration(duration)
        }
    }

    private fun formatDuration(millis: Long): String {
        val totalSec = millis / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return String.format(Locale.getDefault(), "%02d:%02d", min, sec)
    }

    override fun onDestroy() {
        progressHandler.removeCallbacks(progressRunnable)
        discAnimator?.cancel()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
