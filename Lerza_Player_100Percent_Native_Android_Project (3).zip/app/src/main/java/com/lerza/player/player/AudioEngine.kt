package com.lerza.player.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer

/**
 * 100% Native Android Hardware Audio Effects Engine.
 * Utilizes android.media.audiofx APIs directly on the audio session:
 * - 5-Band Hardware Equalizer
 * - Dynamic BassBoost
 * - 3D Virtualizer
 * - LoudnessEnhancer (Boost volume up to 300% / 3000mB gain safely)
 */
class AudioEngine(private val audioSessionId: Int) {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    init {
        try {
            if (audioSessionId != 0) {
                equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
                bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
                virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
                loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply { enabled = true }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBandGain(bandIndex: Short, gainMilliBels: Short) {
        try {
            equalizer?.setBandLevel(bandIndex, gainMilliBels)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getBandGain(bandIndex: Short): Short {
        return try {
            equalizer?.getBandLevel(bandIndex) ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun setBassBoostStrength(strength: Short) { // 0..1000
        try {
            bassBoost?.setStrength(strength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVirtualizerStrength(strength: Short) { // 0..1000
        try {
            virtualizer?.setStrength(strength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 100% to 300% Super Volume Booster:
     * multiplier: 1.0 (Normal), 1.5 (Boost), 2.0 (Super 2x), 3.0 (Max 3x)
     */
    fun setVolumeMultiplier(multiplier: Float) {
        try {
            loudnessEnhancer?.let { enhancer ->
                if (multiplier <= 1.0f) {
                    enhancer.setTargetGain(0)
                } else {
                    // Convert multiplier to target gain in milliBels (up to +3000mB = +30dB)
                    val targetMilliBels = ((multiplier - 1.0f) * 1500f).toInt().coerceIn(0, 3000)
                    enhancer.setTargetGain(targetMilliBels)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        equalizer?.release()
        bassBoost?.release()
        virtualizer?.release()
        loudnessEnhancer?.release()
    }
}
