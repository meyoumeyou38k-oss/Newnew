package com.lerza.player.scanner

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import com.lerza.player.model.MediaTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object MediaScanner {

    suspend fun scanAudioFiles(
        context: Context,
        filterWhatsAppAndRecordings: Boolean = true
    ): List<MediaTrack> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<MediaTrack>()
        val uri: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED
        )
        val selection = "(" + MediaStore.Audio.Media.IS_MUSIC + " != 0 OR " +
                MediaStore.Audio.Media.DURATION + " > 3000)"
        val sortOrder = MediaStore.Audio.Media.TITLE + " ASC"

        try {
            context.contentResolver.query(uri, projection, selection, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Audio Track"
                    val artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Device Storage"
                    val album = cursor.getString(albumCol)?.takeIf { it != "<unknown>" } ?: "Local Music"
                    val duration = cursor.getLong(durCol)
                    val path = cursor.getString(dataCol) ?: ""
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)

                    // WhatsApp voice note & call recording filter
                    if (filterWhatsAppAndRecordings) {
                        val lower = (title + path).lowercase()
                        if (lower.contains("whatsapp") || lower.contains("ptt-") ||
                            lower.contains("voice recorder") || lower.contains("call_rec")
                        ) {
                            continue
                        }
                    }

                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val folderName = if (path.isNotEmpty()) File(path).parentFile?.name ?: "Music" else "Music"
                    val format = if (path.contains(".")) path.substringAfterLast(".").uppercase() else "MP3"

                    tracks.add(
                        MediaTrack(
                            id = id,
                            title = title,
                            artist = artist,
                            album = album,
                            duration = duration,
                            contentUri = contentUri,
                            filePath = path,
                            isVideo = false,
                            fileSize = size,
                            fileFormat = format,
                            folder = folderName,
                            dateAdded = dateAdded
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        tracks
    }

    suspend fun scanVideoFiles(context: Context): List<MediaTrack> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<MediaTrack>()
        val uri: Uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.ARTIST,
            MediaStore.Video.Media.ALBUM,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED
        )
        val sortOrder = MediaStore.Video.Media.DATE_ADDED + " DESC"

        try {
            context.contentResolver.query(uri, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.ALBUM)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    var title = cursor.getString(titleCol)
                    val artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Device Videos"
                    val album = cursor.getString(albumCol)?.takeIf { it != "<unknown>" } ?: "Videos"
                    val duration = cursor.getLong(durCol)
                    val path = cursor.getString(dataCol) ?: ""
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)

                    if (title.isNullOrBlank() && path.isNotEmpty()) {
                        title = File(path).nameWithoutExtension
                    }

                    val contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val folderName = if (path.isNotEmpty()) File(path).parentFile?.name ?: "Videos" else "Videos"
                    val format = if (path.contains(".")) path.substringAfterLast(".").uppercase() else "MP4"

                    videos.add(
                        MediaTrack(
                            id = id,
                            title = title ?: "Video Clip",
                            artist = artist,
                            album = album,
                            duration = duration,
                            contentUri = contentUri,
                            filePath = path,
                            isVideo = true,
                            fileSize = size,
                            fileFormat = format,
                            folder = folderName,
                            dateAdded = dateAdded
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        videos
    }
}
