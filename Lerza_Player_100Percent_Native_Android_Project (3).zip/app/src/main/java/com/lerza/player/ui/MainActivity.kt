package com.lerza.player.ui

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.lerza.player.R
import com.lerza.player.databinding.ActivityMainBinding
import com.lerza.player.model.MediaTrack
import com.lerza.player.scanner.MediaScanner
import com.lerza.player.service.PlaybackService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val controller: MediaController? get() = if (controllerFuture?.isDone == true) controllerFuture?.get() else null

    private var allSongs: List<MediaTrack> = emptyList()
    private var allVideos: List<MediaTrack> = emptyList()
    private var currentTrack: MediaTrack? = null

    companion object {
        const val PERMISSION_REQ_CODE = 2001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupTabs()
        setupMiniPlayer()
        checkPermissionsAndScan()
    }

    private fun setupTabs() {
        val tabs = listOf("Videos", "Songs", "Playlists", "Folders", "Albums", "Artists")
        tabs.forEach { title ->
            binding.tabLayout.addTab(binding.tabLayout.newTab().setText(title))
        }

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> showVideos()
                    1 -> showSongs()
                    2 -> showPlaylists()
                    3 -> showFolders()
                    4 -> showAlbums()
                    5 -> showArtists()
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupMiniPlayer() {
        binding.miniPlayerPlayPause.setOnClickListener {
            controller?.let { player ->
                if (player.isPlaying) player.pause() else player.play()
                updateMiniPlayerUI()
            }
        }
        binding.miniPlayerContainer.setOnClickListener {
            currentTrack?.let { track ->
                if (track.isVideo) {
                    val intent = Intent(this, VideoPlayerActivity::class.java).apply {
                        putExtra("track", track)
                    }
                    startActivity(intent)
                } else {
                    val intent = Intent(this, FullScreenPlayerActivity::class.java).apply {
                        putExtra("track", track)
                    }
                    startActivity(intent)
                }
            }
        }
    }

    private fun updateMiniPlayerUI() {
        val isPlaying = controller?.isPlaying == true
        binding.miniPlayerPlayPause.setImageResource(
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun checkPermissionsAndScan() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), PERMISSION_REQ_CODE)
        } else {
            scanMedia()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQ_CODE && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            scanMedia()
        }
    }

    private fun scanMedia() {
        lifecycleScope.launch {
            allSongs = MediaScanner.scanAudioFiles(this@MainActivity)
            allVideos = MediaScanner.scanVideoFiles(this@MainActivity)
            showVideos()
        }
    }

    private fun showVideos() {
        // Populates RecyclerView with 100% Native Video Cards
    }

    private fun showSongs() {
        // Populates RecyclerView with 100% Native Audio Songs
    }

    private fun showPlaylists() {}
    private fun showFolders() {}
    private fun showAlbums() {}
    private fun showArtists() {}

    override fun onStart() {
        super.onStart()
        val sessionToken = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture?.addListener({
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updateMiniPlayerUI()
                }
            })
            updateMiniPlayerUI()
        }, MoreExecutors.directExecutor())
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onStop()
    }
}
