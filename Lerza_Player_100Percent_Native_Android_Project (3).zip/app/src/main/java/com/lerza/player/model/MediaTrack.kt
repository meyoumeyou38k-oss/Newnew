package com.lerza.player.model

import android.net.Uri
import java.io.Serializable

data class MediaTrack(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long, // in milliseconds
    val contentUri: Uri,
    val filePath: String,
    val isVideo: Boolean,
    val fileSize: Long = 0,
    val fileFormat: String = "",
    val folder: String = "",
    val dateAdded: Long = 0,
    var isFavorite: Boolean = false,
    var isHiddenInVault: Boolean = false
) : Serializable
