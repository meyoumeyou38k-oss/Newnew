package com.lerza.player.model

import java.io.Serializable

data class Playlist(
    val id: String,
    val title: String,
    val description: String = "",
    val trackIds: MutableList<Long> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis()
) : Serializable
