# Proguard rules for Lerza Player Native
-keep class com.lerza.player.** { *; }
-dontwarn androidx.media3.**
