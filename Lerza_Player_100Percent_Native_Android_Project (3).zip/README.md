# Lerza Player Pro - 100% Native Android Project

## Overview
- **100% Pure Native Kotlin & Java** architecture (Zero WebView, Zero HTML wrapper).
- **AndroidX Media3 (ExoPlayer)** for ultra-fast playback of ALL media formats:
  - Audio: MP3, M4A, AAC, FLAC, WAV, OGG, OPUS, WMA, AMR
  - Video: MP4, MKV, WebM, AVI, FLV, MOV, TS, 3GP
- **Lark Player-style Audio/MV Switcher**: seamlessly switch between audio-only playback and high-definition video MV.
- **300% Super Volume Boost**: powered by Android Hardware `LoudnessEnhancer` without clipping.
- **5-Band Equalizer & Bass Boost**: `android.media.audiofx.Equalizer` and `BassBoost`.
- **Custom Penguin Branding**: Adaptive icons, mipmap densities, and transparent UI logo.

## How to Build APK on GitHub Actions
1. Create a new repository on **GitHub.com**.
2. Extract or upload all files from this ZIP to the repository root.
3. Commit and push to `main` branch.
4. Go to **Actions** tab on GitHub.
5. The workflow **Build Native Android APK** will run automatically and output:
   `release-output/LerzaPlayerPro-v2.5.0-Debug.apk`
6. Click on the completed action run and download the **Lerza-Player-Pro-APK** artifact!
